<?php
/**
 * Miscellaneous stubs for phan
 *
 * @created      25.01.2021
 * @author       smiley <smiley@chillerlan.net>
 * @copyright    2021 smiley
 * @license      MIT
 */

class GdImage{}
